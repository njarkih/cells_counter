UPLOAD_FOLDER = 'static/photos/'
ALLOWED_EXTENSIONS = set(['jpg', 'jpeg', 'png'])
MODEL_PATH = "static/model/model_950_epochs.pt"